package com.sparktek.sparkbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class ChatService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var title = "SparkBot chalu hai"
    private var body = "Neeche 'Likho' dabao aur kuch bhi pucho"

    override fun onBind(i: Intent?): IBinder? = null

    private fun build(): Notification {
        val ri = RemoteInput.Builder("q").setLabel("Kuch bhi pucho...").build()
        val replyPi = PendingIntent.getService(
            this, 0, Intent(this, ChatService::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_send), "Likho", replyPi
        ).addRemoteInput(ri).build()
        val openPi = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "spark")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(openPi)
            .addAction(action)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun show() {
        val n = build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("spark", "SparkBot", NotificationManager.IMPORTANCE_LOW))

        var q: String? = null
        if (intent != null) {
            val results = RemoteInput.getResultsFromIntent(intent)
            q = results?.getCharSequence("q")?.toString()?.trim()
        }

        if (q != null && q.isNotEmpty()) {
            val question: String = q
            title = "Soch raha hu..."
            body = "Tum: $question"
            show()
            Thread {
                val reply = Chat.ask(this, question)
                Chat.log.append("Tum: $question\nBot: $reply\n\n")
                main.post {
                    title = "SparkBot"
                    body = reply
                    show()
                }
            }.start()
        } else {
            show()
        }
        return START_STICKY
    }
}
