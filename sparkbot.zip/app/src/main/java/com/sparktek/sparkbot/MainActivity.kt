package com.sparktek.sparkbot

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*

class MainActivity : Activity() {
    private lateinit var logView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sp = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        val title = TextView(this).apply { text = "SparkBot Chat"; textSize = 28f }
        val url = EditText(this).apply {
            hint = "Backend URL (https://.../api/chat)"
            setText(sp.getString("url", "")); setSingleLine()
        }
        val secret = EditText(this).apply {
            hint = "App secret"; setText(sp.getString("secret", "")); setSingleLine()
        }
        val start = Button(this).apply { text = "Start (notification me chat)" }
        val stop = Button(this).apply { text = "Stop" }
        logView = TextView(this).apply { textSize = 15f; setTextIsSelectable(true) }
        val scroll = ScrollView(this).apply { addView(logView) }

        start.setOnClickListener {
            sp.edit().putString("url", url.text.toString().trim())
                .putString("secret", secret.text.toString().trim()).apply()
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
            } else {
                startChat()
            }
        }
        stop.setOnClickListener { stopService(Intent(this, ChatService::class.java)) }

        root.addView(title); root.addView(url); root.addView(secret)
        root.addView(start); root.addView(stop)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        logView.text = Chat.log.toString()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        startChat()
    }

    private fun startChat() {
        startForegroundService(Intent(this, ChatService::class.java))
        Toast.makeText(this, "Chalu! Notification bar neeche kheencho", Toast.LENGTH_LONG).show()
    }
}
