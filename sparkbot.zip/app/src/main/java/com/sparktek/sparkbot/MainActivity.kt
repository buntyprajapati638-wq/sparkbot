package com.sparktek.sparkbot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sp = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        val title = TextView(this).apply { text = "SparkBot"; textSize = 28f }
        val url = EditText(this).apply {
            hint = "Backend URL (…/.netlify/functions/chat)"
            setText(sp.getString("url", "")); setSingleLine()
        }
        val secret = EditText(this).apply {
            hint = "App secret"; setText(sp.getString("secret", "")); setSingleLine()
        }
        val start = Button(this).apply { text = "Start floating bubble" }
        val stop = Button(this).apply { text = "Stop bubble" }

        start.setOnClickListener {
            sp.edit().putString("url", url.text.toString().trim())
                .putString("secret", secret.text.toString().trim()).apply()
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "'Display over other apps' ON karo, fir wapas aake Start dabao", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
                }
                startForegroundService(Intent(this, FloatingService::class.java))
                Toast.makeText(this, "Bubble chalu!", Toast.LENGTH_SHORT).show()
            }
        }
        stop.setOnClickListener { stopService(Intent(this, FloatingService::class.java)) }

        root.addView(title); root.addView(url); root.addView(secret); root.addView(start); root.addView(stop)
        setContentView(root)
    }
}
