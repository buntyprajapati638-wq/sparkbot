package com.sparktek.sparkbot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Chat {
    val history = JSONArray()
    val log = StringBuilder()

    @Synchronized
    fun ask(ctx: Context, text: String): String {
        val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        history.put(JSONObject().put("role", "user").put("content", text))
        try {
            val c = URL(sp.getString("url", "")).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-app-secret", sp.getString("secret", "") ?: "")
            c.doOutput = true
            c.outputStream.use { it.write(JSONObject().put("messages", history).toString().toByteArray()) }
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
            if (code !in 200..299) {
                history.remove(history.length() - 1)
                return "Error $code: $body"
            }
            val reply = JSONObject(body).getString("reply")
            history.put(JSONObject().put("role", "assistant").put("content", reply))
            return reply
        } catch (e: Exception) {
            history.remove(history.length() - 1)
            return "Error: ${e.message}"
        }
    }
}
