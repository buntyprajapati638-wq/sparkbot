package com.sparktek.sparkbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private lateinit var chatText: TextView
    private lateinit var scroll: ScrollView
    private val history = JSONArray()
    private val main = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("spark", "SparkBot", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "spark")
            .setContentTitle("SparkBot chalu hai")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (bubble == null) { buildBubble(); buildPanel() }
        return START_STICKY
    }

    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun buildBubble() {
        val b = TextView(this).apply {
            text = "⚡"; textSize = 26f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#FF6B00")) }
        }
        val lp = WindowManager.LayoutParams(
            dp(56), dp(56), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = dp(200) }

        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        lp.x = sx + dx; lp.y = sy + dy
                        wm.updateViewLayout(v, lp)
                    }
                    MotionEvent.ACTION_UP -> if (!moved) showPanel(true)
                }
                return true
            }
        })
        wm.addView(b, lp)
        bubble = b
    }

    private fun buildPanel() {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(Color.parseColor("#F2121212")) }
            visibility = View.GONE
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text = "⚡ SparkBot"; setTextColor(Color.WHITE); textSize = 18f }
        val clear = Button(this).apply { text = "Clear"; setOnClickListener { history.let { while (it.length() > 0) it.remove(0) }; chatText.text = "" } }
        val close = Button(this).apply { text = "✕"; setOnClickListener { showPanel(false) } }
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(clear); header.addView(close)

        chatText = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setTextIsSelectable(true) }
        scroll = ScrollView(this).apply { addView(chatText) }

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val input = EditText(this).apply {
            hint = "Kuch bhi pucho…"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            maxLines = 3
        }
        val send = Button(this).apply { text = "Send" }
        send.setOnClickListener {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) { input.setText(""); send(t) }
        }
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(send)

        p.addView(header)
        p.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        p.addView(row)

        val h = (resources.displayMetrics.heightPixels * 0.45).toInt()
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, h, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP; y = dp(40)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        }
        wm.addView(p, lp)
        panel = p
    }

    private fun showPanel(show: Boolean) {
        panel?.visibility = if (show) View.VISIBLE else View.GONE
        bubble?.visibility = if (show) View.GONE else View.VISIBLE
    }

    private fun append(s: String) {
        chatText.append(s)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun send(text: String) {
        history.put(JSONObject().put("role", "user").put("content", text))
        append("Tum: $text\n")
        Thread {
            val reply = try { call() } catch (e: Exception) { "Error: ${e.message}" }
            main.post { append("Bot: $reply\n\n") }
        }.start()
    }

    private fun call(): String {
        val sp = getSharedPreferences("cfg", MODE_PRIVATE)
        val c = URL(sp.getString("url", "")).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000; c.readTimeout = 60000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-app-secret", sp.getString("secret", "") ?: "")
        c.doOutput = true
        c.outputStream.use { it.write(JSONObject().put("messages", history).toString().toByteArray()) }
        val code = c.responseCode
        val body = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code !in 200..299) return "Error $code: $body"
        val reply = JSONObject(body).getString("reply")
        history.put(JSONObject().put("role", "assistant").put("content", reply))
        return reply
    }

    override fun onDestroy() {
        bubble?.let { wm.removeView(it) }
        panel?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
